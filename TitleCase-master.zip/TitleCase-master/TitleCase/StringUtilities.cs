﻿using System;

namespace TitleCase
{
    public static class StringUtilities
    {
        public static string TitleCase(string title, string minorWords ="")
        {
            var wordArray = SplitString(title); //Each word of the title forms an element of an array
            var minorWordArray = SplitString(minorWords); //Each word of the minor word list fors an element of an array
            
            if (string.IsNullOrEmpty(title)) //Check if the title is blank
            {
                return string.Empty; //No further processing required i9f title is blank
            }

            wordArray[0] = CapitalizeSingleWord(wordArray[0]); //Always capitalize the first word of the title
                for (int i = 1; i <wordArray.Length; i++) //For loop to step through remaining elements of the array
                {
                    if (CurrentWordIsMinor(wordArray[i], minorWordArray)) //Check if the current word is a minor word
                    {
                        wordArray[i] = wordArray[i].ToLower(); //minor words must be lower case
                    }
                    else
                    {
                        wordArray[i] = CapitalizeSingleWord(wordArray[i]); //Other words must have first letter capitalized
                    }
                }
                return string.Join(" ", wordArray); //Concatenate each word to single string with a space in between
        }
        public static bool CurrentWordIsMinor(string currentWord, string[] minorWordArray) //Checks if a word is a minor word
        {
            if (minorWordArray.Equals(null)) //if there is no minor words, treat as normal word
            {
                return false;
            }
            else return Array.IndexOf(minorWordArray, currentWord) >-1; //return true if title word appears in minor word array
        }
        public static string CapitalizeSingleWord(string word) //Capitalizes the first letter of a word
        {
            word = word.ToLower(); //make all letters in word lowercase
            char[] letters = word.ToCharArray(); //break down the word into an array of individual letters
            letters[0] = (char)(letters[0] - 32); //Subtract 32 from the ASCII value of the first letter
            return new string(letters); 
        }
        public static string[] SplitString(string inputString) //Put individual words from a string into elements of an array
        {
            if (string.IsNullOrEmpty(inputString)) //check if the input string is blank
            {
                string[] emptyArray = { "" }; //declare an empty array
                return emptyArray;
            }
            else 
            {
                var stringArray = inputString.Split(' '); // Create array to hold individual words seperated by a space
                for (var i = 0; i < stringArray.Length; i++) //step through each element of the array
                {
                    stringArray[i] = stringArray[i].ToLower(); //force each word to lower case
                }
                return stringArray;
            }
        }
    }
}